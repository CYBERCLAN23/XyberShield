// Année footer
document.getElementById('year').textContent = new Date().getFullYear();

// Filtres & recherche
const grid = document.getElementById('eduGrid');
const cards = Array.from(grid.querySelectorAll('.edu-card'));
const filterBtns = document.querySelectorAll('.filter-btn');
const searchInput = document.getElementById('searchInput');

function applyFilters() {
  const activeFilterBtn = document.querySelector('.filter-btn.active');
  const typeFilter = activeFilterBtn ? activeFilterBtn.dataset.filter : 'all';
  const query = (searchInput.value || '').toLowerCase().trim();

  cards.forEach(card => {
    const matchesType = (typeFilter === 'all') || (card.dataset.type === typeFilter);
    const matchesQuery = card.dataset.title.toLowerCase().includes(query);
    card.style.display = (matchesType && matchesQuery) ? '' : 'none';
  });
}

filterBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    filterBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    applyFilters();
  });
});
searchInput.addEventListener('input', applyFilters);

// Modal vidéo
const videoModal = new bootstrap.Modal(document.getElementById('videoModal'));
const videoFrame = document.getElementById('videoFrame');

grid.addEventListener('click', (e) => {
  const playButton = e.target.closest('.play-btn');
  if (playButton){
    const src = playButton.getAttribute('data-video');
    videoFrame.src = src;
    videoModal.show();
  }
});

// Stopper la vidéo à la fermeture
document.getElementById('videoModal').addEventListener('hidden.bs.modal', () => {
  videoFrame.src = '';
});

// Lightbox images
const imageModal = new bootstrap.Modal(document.getElementById('imageModal'));
const lightboxImg = document.getElementById('lightboxImg');

grid.addEventListener('click', (e) => {
  const thumb = e.target.closest('.thumb');
  if (thumb && thumb.dataset.image){
    lightboxImg.src = thumb.dataset.image;
    imageModal.show();
  }
});
