"use strict";
// Original file: proto/channelz.proto
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=GetServerRequest.js.map