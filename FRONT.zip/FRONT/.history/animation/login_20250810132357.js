  // =========================
        // NOTIFICATION HANDLING
        // =========================
        function showNotification(message, type, targetId) {
            const notif = document.getElementById(targetId);
            notif.textContent = message;
            notif.className = `notification ${type}`;
            notif.style.display = "block";
            setTimeout(() => {
                notif.style.display = "none";
            }, 4000);
        }

        // =========================
        // VALIDATION HELPERS
        // =========================
        function isValidEmail(email) {
            const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return regex.test(email);
        }
        
        function isValidPassword(password) {
            // At least 8 chars, 1 uppercase, 1 lowercase, 1 digit
            const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[A-Za-z\d]{8,}$/;
            return regex.test(password);
        }

        // =========================
        // LOGIN LOGIC
        // =========================
        function login() {
            const email = document.getElementById("email").value;
            const password = document.getElementById("password").value;
            
            // Hide previous alerts
            document.getElementById("email-alert").classList.remove("show");
            document.getElementById("password-alert").classList.remove("show");
            document.getElementById("email-alert").textContent = "";
            document.getElementById("password-alert").textContent = "";
            
            let hasError = false;

            // Email validation
            if (!email) {
                document.getElementById("email-alert").textContent = "Veuillez remplir l'email 🔴";
                document.getElementById("email-alert").classList.add("show");
                document.getElementById("email").classList.add("input-error");
                hasError = true;
            } else if (!isValidEmail(email)) {
                document.getElementById("email-alert").textContent = "Email invalide ❌";
                document.getElementById("email-alert").classList.add("show");
                document.getElementById("email").classList.// Toggle password visibility
function togglePassword() {
    const passwordInput = document.getElementById("password");
    const eyeIcon = document.getElementById("eye-icon");
    if (!passwordInput || !eyeIcon) return;
    if (passwordInput.type === "password") {
        passwordInput.type = "text";
        eyeIcon.classList.remove("fa-eye");
        eyeIcon.classList.add("fa-eye-slash");
    } else {
        passwordInput.type = "password";
        eyeIcon.classList.remove("fa-eye-slash");
        eyeIcon.classList.add("fa-eye");
    }
}

function showAlert(id, message) {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent = message;
    el.classList.add("show");
}

function hideAlert(id) {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent = '';
    el.classList.remove("show");
}

function showNotification(message, type='success') {
    const notification = document.getElementById('welcome-notification');
    if (!notification) return;
    notification.textContent = message;
    notification.className = 'notification ' + type;
    notification.style.display = 'block';
    setTimeout(() => { notification.style.display = 'none'; }, 2200);
}

function login() {
    const email = document.getElementById('email');
    const password = document.getElementById('password');
    let valid = true;
    if (!email || email.value.trim() === '') { showAlert('email-alert','Email is required'); valid = false; } else hideAlert('email-alert');
    if (!password || password.value.trim() === '') { showAlert('password-alert','Password is required'); valid = false; } else hideAlert('password-alert');
    if (!valid) return;
    showNotification('Login successful!', 'success');
}

function register() {
    const name = document.getElementById('name');
    const pseudo = document.getElementById('pseudo');
    const email = document.getElementById('reg-email');
    const password = document.getElementById('reg-password');
    const confirmPassword = document.getElementById('confirm-password');
    if (!name || !pseudo || !email || !password || !confirmPassword) { showNotification('Fields missing','error'); return; }
    if (name.value.trim()===''||pseudo.value.trim()===''||email.value.trim()===''||password.value.trim()==='') { showNotification('All fields required','error'); return; }
    if (password.value !== confirmPassword.value) { showNotification('Passwords do not match','error'); return; }
    showNotification('Registration successful!','success');
}

// Switch to register: add .switch (CSS handles order/background), fade forms
function switchForm() {
    const container = document.getElementById('container');
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    if (!container || !loginForm || !registerForm) return;
    container.classList.add('switch');
    loginForm.classList.remove('show'); loginForm.classList.add('hide');
    setTimeout(() => {
        registerForm.classList.remove('hide'); registerForm.classList.add('show');
    }, 240);
}

// Switch back to login
function showLogin() {
    const container = document.getElementById('container');
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    if (!container || !loginForm || !registerForm) return;
    container.classList.remove('switch');
    registerForm.classList.remove('show'); registerForm.classList.add('hide');
    setTimeout(() => {
        loginForm.classList.remove('hide'); loginForm.classList.add('show');
    }, 240);
}

document.addEventListener('click', function(e){ const n = document.getElementById('welcome-notification'); if (n && e.target === n) n.style.display='none'; });
add("input-error");
                hasError = true;
            } else {
                document.getElementById("email").classList.remove("input-error");
            }

            // Password validation
            if (!password) {
                document.getElementById("password-alert").textContent = "Veuillez remplir le mot de passe 🔴";
                document.getElementById("password-alert").classList.add("show");
                document.getElementById("password").classList.add("input-error");
                hasError = true;
            } else {
                let pwdErrors = [];
                if (password.length < 8) pwdErrors.push("Au moins 8 caractères");
                if (!/[A-Z]/.test(password)) pwdErrors.push("Une majuscule");
                if (!/[a-z]/.test(password)) pwdErrors.push("Une minuscule");
                if (!/\d/.test(password)) pwdErrors.push("Un chiffre");
                
                if (pwdErrors.length > 0) {
                    document.getElementById("password-alert").textContent = "Mot de passe invalide: " + pwdErrors.join(", ") + " ❌";
                    document.getElementById("password-alert").classList.add("show");
                    document.getElementById("password").classList.add("input-error");
                    hasError = true;
                } else {
                    document.getElementById("password").classList.remove("input-error");
                }
            }

            // Show notification
            if (hasError) {
                showNotification("Erreur dans le formulaire. Corrigez les champs en rouge.", "error", "notification");
            } else {
                showNotification("Connexion réussie ✅", "success", "notification");
                // Show welcome notification 
                const welcome = document.getElementById("welcome-notification");
                welcome.textContent = "Bienvenue sur XyberShield! Vous êtes connecté.";
                welcome.className = "notification success";
                welcome.style.display = "block";
                setTimeout(() => {
                    welcome.style.display = "none";
                }, 4000);
            }
        }

        // =========================
        // REGISTER LOGIC
        // =========================
        function register() {
            const name = document.getElementById("name").value;
            const pseudo = document.getElementById("pseudo").value;
            const email = document.getElementById("reg-email").value;
            const password = document.getElementById("reg-password").value;
            const confirmPassword = document.getElementById("confirm-password").value;
            
            if (!name || !pseudo || !email || !password || !confirmPassword) {
                showNotification("Veuillez remplir tous les champs ⚠️", "error", "notification");
                return;
            }
            
            if (password !== confirmPassword) {
                showNotification("Les mots de passe ne correspondent pas ⚠️", "error", "notification");
                return;
            }
            
            if (!isValidPassword(password)) {
                showNotification("Mot de passe invalide. Doit contenir au moins 8 caractères, une majuscule, une minuscule et un chiffre.", "error", "notification");
                return;
            }
            
            showNotification("Enregistrement réussi 🎉", "success", "notification");
        }

        // =========================
        // PASSWORD VISIBILITY TOGGLE
        // =========================
        function togglePassword() {
            const eyeIcon = document.getElementById("eye-icon");
            const passwordInput = document.getElementById("password");
            if(passwordInput.type === "password"){
                passwordInput.type = "text";
                eyeIcon.className = 'fa fa-eye-slash';
            } else {
                passwordInput.type = "password";
                eyeIcon.className = 'fa fa-eye';
            }
        }

        // =========================
        // FORM SWITCHING
        // =========================

        //////////////////////////////////////////////
      .............................................................................................................................................................................................................................................................................................................................................................................................................;...................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................
// ======== SWITCH TO REGISTER FORM ========
function switchForm() {
    const container = document.getElementById("container");
    container.classList.add("switch");
    setTimeout(() => {
        document.getElementById("register-fields").style.display = "block";
        document.querySelector(".login-wrapper").style.display = "none";
    }, 400); // wait for animation
}

// ======== SWITCH BACK TO LOGIN FORM ========
function showLogin() {
    const container = document.getElementById("container");
    container.classList.remove("switch");
    setTimeout(() => {
        document.getElementById("register-fields").style.display = "none";
        document.querySelector(".login-wrapper").style.display = "flex";
    }, 400); // wait for animation
}


// ======== REGISTER FUNCTION (DUMMY VALIDATION) ========
function register() {
    const name = document.getElementById("name");
    const pseudo = document.getElementById("pseudo");
    const email = document.getElementById("reg-email");
    const password = document.getElementById("reg-password");
    const confirmPassword = document.getElementById("confirm-password");

    let valid = true;

    if (name.value.trim() === "" || pseudo.value.trim() === "" || email.value.trim() === "" || password.value.trim() === "" || confirmPassword.value.trim() === "") {
        showNotification("All fields are required", "error");
        valid = false;
    } else if (password.value !== confirmPassword.value) {
        showNotification("Passwords do not match", "error");
        valid = false;
    }

    if (valid) {
        showNotification("Registration successful!", "success");
    }
}

